package br.com.fiap.bo;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

import br.com.fiap.estoque.EstoqueBasicoStub;

public class EstoqueBO {
	
	public String listagem(int codigo) {
		
		try {
		EstoqueBasicoStub ebs = new EstoqueBasicoStub();
		
		Listar listar = new Listar();
		listar.setCodigo(codigo);
		
		ListarResponse lre = ebs.listar(listar);
		
		return lre.get_return();
		
		}catch (AxisFault e) {
			e.printStackTrace();
		}catch (RemoteException e) {
			e.printStackTrace();
		}
		return null;
	}
}

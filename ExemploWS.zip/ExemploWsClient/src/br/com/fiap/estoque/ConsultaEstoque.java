package br.com.fiap.estoque;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

import br.com.fiap.estoque.EstoqueBasicoStub.Soma;
import br.com.fiap.estoque.EstoqueBasicoStub.SomaResponse;

public class ConsultaEstoque {

	public static void main(String[] args) {
		
	try {	
		EstoqueBasicoStub ebs = new EstoqueBasicoStub();
		
		Soma sm = new Soma();
		sm.setN1(4);
		sm.setN2(9);
		
		SomaResponse smr = ebs.soma(sm);
		
		System.out.println("O resultado ser� :" + smr.get_return());
		
		
			
		}catch(AxisFault e){
			e.printStackTrace();
		}catch(RemoteException e) {
			e.printStackTrace();
		}

	}

}

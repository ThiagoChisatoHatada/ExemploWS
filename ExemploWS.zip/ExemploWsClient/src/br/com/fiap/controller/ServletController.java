package br.com.fiap.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.fiap.bo.EstoqueBO;

/**
 * Servlet implementation class ServletController
 */
public class ServletController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String resultado ="";
		int codigo = Integer.parseInt(request.getParameter("nrCod"));
		
		EstoqueBO eb = new EstoqueBO();
		
		resultado = eb.listagem(codigo);
		
		request.setAttribute("atributoProd", resultado);
		
		request.getRequestDispatcher("resultado.jsp").forward(request, response);
		
	}

}

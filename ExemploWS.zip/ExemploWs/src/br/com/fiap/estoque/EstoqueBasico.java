package br.com.fiap.estoque;

public class EstoqueBasico {
	
	public int soma(int n1, int n2) {
		return (n1+n2);
	}
	
	
}
